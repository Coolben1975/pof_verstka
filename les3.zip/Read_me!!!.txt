Добрый Вам день.
Ну вот, все-таки успел, но не разобрался до конца.
Прошу помощи. При чем - эта проблема, вылезла в новом задании, но отразилась на странице - catalog.html
Прям в папке с работой, есть файлик - "слились буквы.jpg" 
На нем видно, что с блоком input - явно, что-то не так, пропал отступ между буквой и окном для клика.
Что я не пробовал - не помогает.
Еще, не реально наверное звучит, но с этой же страницей возникает проблема (иногда), просто перестает работать 
div "container". Правая сторона уходит за границу экрана и пока не перекомпилируешь sccs и не перезапустишь - не 
восстанавливается.
Может посмотрите и подскажете?
Еще я не знаю как правильно соединять  в препроцессоре, пример:

когда ссылаюсь на конкретный элемент, через ">" 

.services_wrap {
        flex-direction: row;
        justify-content: space-between;
        align-items: center
 }
  *********************
 .services_wrap > div {
        margin: 104px 0;
 }

как праильно соединить?

 .services_wrap {
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding-left: 0;
        padding-right: 0;

 & > div {
        margin: 104px 0;
}

или    
     
.services_wrap {
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding-left: 0;
        padding-right: 0;

 & & > div {
        margin: 104px 0;
}

или еще как-то?

Спасибо!
  
